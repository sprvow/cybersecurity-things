#include <stdio.h>
#include <stdlib.h>

long get_file_size(FILE *f) {
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);
    return size;
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: ./otp_cipher input key output\n");
        return EXIT_FAILURE;
    }

    FILE *in = fopen(argv[1], "rb");
    FILE *key = fopen(argv[2], "rb");
    FILE *out = fopen(argv[3], "wb");

    if (!in || !key || !out) {
        printf("File error\n");
        return EXIT_FAILURE;
    }

    long in_size = get_file_size(in);
    long key_size = get_file_size(key);

    if (key_size < in_size) {
        printf("Key too short!\n");
        return EXIT_FAILURE;
    }

    unsigned char b1, b2;

    while (fread(&b1, 1, 1, in) == 1 &&
           fread(&b2, 1, 1, key) == 1) {

        unsigned char encrypted = b1 ^ b2;
        fwrite(&encrypted, 1, 1, out);
    }

    fclose(in);
    fclose(key);
    fclose(out);

    return EXIT_SUCCESS;
}
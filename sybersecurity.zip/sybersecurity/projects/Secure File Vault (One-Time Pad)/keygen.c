#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: ./keygen size\n");
        return EXIT_FAILURE;
    }

    int size = atoi(argv[1]);

    FILE *urandom = fopen("/dev/urandom", "rb");
    FILE *out = fopen("otp.key", "wb");

    if (!urandom || !out) {
        printf("Error\n");
        return EXIT_FAILURE;
    }

    unsigned char buffer;

    for (int i = 0; i < size; i++) {
        fread(&buffer, 1, 1, urandom);
        fwrite(&buffer, 1, 1, out);
    }

    fclose(urandom);
    fclose(out);

    return EXIT_SUCCESS;
}
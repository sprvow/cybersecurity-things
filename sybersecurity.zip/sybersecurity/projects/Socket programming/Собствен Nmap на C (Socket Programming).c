#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>

int main() {

    const char *target_ip = "127.0.0.1";

    int start_port = 1;
    int end_port = 100;

    printf("--- Starting Scan on %s ---\n", target_ip);

    for(int port = start_port; port <= end_port; port++) {

        int sock = socket(AF_INET, SOCK_STREAM, 0);

        if(sock < 0) {
            printf("Socket creation failed.\n");
            return 1;
        }

        struct sockaddr_in target;

        target.sin_family = AF_INET;
        target.sin_port = htons(port);
        target.sin_addr.s_addr = inet_addr(target_ip);

        int result = connect(
            sock,
            (struct sockaddr*)&target,
            sizeof(target)
        );

        if(result == 0) {
            printf("[OPEN] Port %d is open\n", port);
        }

        close(sock);
    }

    printf("Scan finished.\n");

    return 0;
}
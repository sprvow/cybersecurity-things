#include <stdio.h>
#include <string.h>
#include <openssl/hmac.h>

void bytes_to_hex(unsigned char *bytes, int len, char *hex_out) {

    for(int i = 0; i < len; i++) {
        sprintf(hex_out + (i * 2), "%02x", bytes[i]);
    }

    hex_out[len * 2] = '\0';
}

int main() {

    char incoming_payload[] =
        "from=Alice&to=Hacker&amount=9999";

    char incoming_signature[] =
        "92a8e8f8c9b2d3c4";

    char api_key[] = "BankSecretKey2026";

    printf("--- Incoming API Request ---\n");

    printf("Payload: %s\n", incoming_payload);

    printf("Received Signature: %s\n\n",
           incoming_signature);


    unsigned char server_mac[EVP_MAX_MD_SIZE];
    unsigned int mac_len;

    HMAC(
        EVP_sha256(),
        api_key,
        strlen(api_key),
        (unsigned char*)incoming_payload,
        strlen(incoming_payload),
        server_mac,
        &mac_len
    );


    char server_mac_hex[65];

    bytes_to_hex(
        server_mac,
        mac_len,
        server_mac_hex
    );

    printf("Server Signature: %s\n",
           server_mac_hex);


    if(strcmp(
        server_mac_hex,
        incoming_signature) == 0) {

        printf("\n[200 OK]\n");
        printf("Transaction approved.\n");

    }
    else {

        printf("\n[401 ERROR]\n");
        printf("Invalid signature detected!\n");
        printf("Possible tampering attempt!\n");
    }

    return 0;
}
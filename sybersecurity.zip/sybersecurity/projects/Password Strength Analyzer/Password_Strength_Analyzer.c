#include <stdio.h>
#include <string.h>
#include <ctype.h>

int analyze_password(const char *pass) {
    int score = 0;
    int hasLower = 0, hasUpper = 0, hasDigit = 0, hasSpecial = 0;

    char *weak[] = {"password", "123456", "admin"};

    int len = strlen(pass);
    score += len;

    for (int i = 0; i < len; i++) {
        if (islower(pass[i])) hasLower = 1;
        else if (isupper(pass[i])) hasUpper = 1;
        else if (isdigit(pass[i])) hasDigit = 1;
        else hasSpecial = 1;
    }

    if (hasLower) score += 10;
    if (hasUpper) score += 10;
    if (hasDigit) score += 15;
    if (hasSpecial) score += 20;

    for (int i = 0; i < 3; i++) {
        if (strcmp(pass, weak[i]) == 0) {
            score -= 20;
        }
    }

    if (score < 0) score = 0;
    if (score > 100) score = 100;

    return score;
}

int main() {
    char pass[100];

    printf("Enter password: ");
    scanf("%s", pass);

    int score = analyze_password(pass);

    printf("Password strength: %d/100\n", score);

    return 0;
}
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <openssl/evp.h>

#define KEY "01234567890123456789012345678901" // 32 bytes
#define IV  "0123456789012345"                 // 16 bytes

int encrypt(unsigned char *plaintext, int plaintext_len,
            unsigned char *key, unsigned char *iv,
            unsigned char *ciphertext) {

    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    int len, ciphertext_len;

    EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv);
    EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len);
    ciphertext_len = len;

    EVP_EncryptFinal_ex(ctx, ciphertext + len, &len);
    ciphertext_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return ciphertext_len;
}

int decrypt(unsigned char *ciphertext, int ciphertext_len,
            unsigned char *key, unsigned char *iv,
            unsigned char *plaintext) {

    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    int len, plaintext_len;

    EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv);
    EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len);
    plaintext_len = len;

    EVP_DecryptFinal_ex(ctx, plaintext + len, &len);
    plaintext_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return plaintext_len;
}

void bin_to_hex(unsigned char *in, int len, char *out) {
    for (int i = 0; i < len; i++) {
        sprintf(out + i * 2, "%02X", in[i]);
    }
    out[len * 2] = '\0';
}

int hex_to_bin(const char *hex, unsigned char *out) {
    int len = strlen(hex) / 2;
    for (int i = 0; i < len; i++) {
        sscanf(hex + 2*i, "%2hhx", &out[i]);
    }
    return len;
}

int main() {

    char input[256];

    while (1) {
        printf("Enter message: ");
        fgets(input, sizeof(input), stdin);

        input[strcspn(input, "\n")] = 0;

        if (strcmp(input, "EXIT") == 0) break;

        unsigned char ciphertext[512];
        unsigned char decrypted[512];
        char hex[1024];

        int cipher_len = encrypt((unsigned char*)input, strlen(input),
                                (unsigned char*)KEY, (unsigned char*)IV,
                                ciphertext);

        bin_to_hex(ciphertext, cipher_len, hex);

        printf("[NETWORK SEND]: %s\n", hex);

        unsigned char received_bin[512];
        int recv_len = hex_to_bin(hex, received_bin);

        int plain_len = decrypt(received_bin, recv_len,
                                (unsigned char*)KEY, (unsigned char*)IV,
                                decrypted);

        decrypted[plain_len] = '\0';

        printf("[NETWORK RECV]: %s\n\n", decrypted);
    }

    return 0;
}
echo "=== Matryoshka Secure Communication Tool ==="

if [ ! -f "message.txt" ]; then
    echo "message.txt not found!"
    exit 1
fi

if [ ! -f "cover.jpg" ]; then
    echo "cover.jpg not found!"
    exit 1
fi

echo "[1] Encrypting message..."

openssl enc -aes-256-cbc \
-salt \
-in message.txt \
-out message.enc

if [ $? -ne 0 ]; then
    echo "Encryption failed."
    exit 1
fi


echo "[2] Hiding encrypted file..."

steghide embed \
-cf cover.jpg \
-ef message.enc

if [ $? -ne 0 ]; then
    echo "Steganography failed."
    exit 1
fi


echo "[3] Removing temporary files..."

rm message.txt
rm message.enc

echo
echo "[SUCCESS]"
echo "Secret message hidden successfully."
echo "Only the innocent image remains."
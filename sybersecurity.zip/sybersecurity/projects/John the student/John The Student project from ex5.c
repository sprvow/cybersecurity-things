#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>

#define MAX_LINE 256

void hash_password(const char *password, unsigned char *out, unsigned int *len) {
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    EVP_DigestInit_ex(ctx, EVP_sha256(), NULL);
    EVP_DigestUpdate(ctx, password, strlen(password));
    EVP_DigestFinal_ex(ctx, out, len);
    EVP_MD_CTX_free(ctx);
}

void to_hex(unsigned char *hash, unsigned int len, char *out) {
    for (unsigned int i = 0; i < len; i++) {
        sprintf(out + i * 2, "%02x", hash[i]);
    }
    out[len * 2] = '\0';
}

int dictionary_attack(const char *hash, FILE *dict, char *result) {
    char word[128];
    unsigned char hash_bin[EVP_MAX_MD_SIZE];
    unsigned int len;
    char hash_hex[EVP_MAX_MD_SIZE * 2 + 1];

    rewind(dict);

    while (fgets(word, sizeof(word), dict)) {
        word[strcspn(word, "\n")] = 0;

        hash_password(word, hash_bin, &len);
        to_hex(hash_bin, len, hash_hex);

        if (strcmp(hash, hash_hex) == 0) {
            strcpy(result, word);
            return 1;
        }
    }
    return 0;
}

int brute_force_pin(const char *hash, char *result) {
    unsigned char hash_bin[EVP_MAX_MD_SIZE];
    unsigned int len;
    char hash_hex[EVP_MAX_MD_SIZE * 2 + 1];
    char pin[5];

    for (int i = 0; i <= 9999; i++) {
        sprintf(pin, "%04d", i);

        hash_password(pin, hash_bin, &len);
        to_hex(hash_bin, len, hash_hex);

        if (strcmp(hash, hash_hex) == 0) {
            strcpy(result, pin);
            return 1;
        }
    }
    return 0;
}

int main(int argc, char *argv[]) {

    if (argc != 3) {
        printf("Usage: %s shadow.txt dictionary.txt\n", argv[0]);
        return 1;
    }

    FILE *shadow = fopen(argv[1], "r");
    FILE *dict = fopen(argv[2], "r");

    if (!shadow || !dict) {
        printf("Error opening files\n");
        return 1;
    }

    char line[MAX_LINE];

    printf("--- Results ---\n");

    while (fgets(line, sizeof(line), shadow)) {

        char *username = strtok(line, ":");
        char *hash = strtok(NULL, ":\n");

        if (!username || !hash) continue;

        char found[128];

        if (dictionary_attack(hash, dict, found)) {
            printf("%s : %s (dictionary)\n", username, found);
        }
        else if (brute_force_pin(hash, found)) {
            printf("%s : %s (brute-force)\n", username, found);
        }
        else {
            printf("%s : [NOT CRACKED]\n", username);
        }
    }

    fclose(shadow);
    fclose(dict);

    return 0;
}

openssl pkeyutl -decrypt \
-in encrypted_aes_key.enc \
-inkey private.pem \
-pkeyopt rsa_padding_mode:oaep \
-out aes_key.bin

openssl enc -d -aes-256-cbc \
-in data.enc \
-out decrypted.zip \
-pass file:./aes_key.bin

rm aes_key.bin

echo "Decryption done!"
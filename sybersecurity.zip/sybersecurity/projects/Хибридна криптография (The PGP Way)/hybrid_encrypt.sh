
openssl rand -out aes_key.bin 32

openssl enc -aes-256-cbc -salt \
-in big_data.zip \
-out data.enc \
-pass file:./aes_key.bin

openssl pkeyutl -encrypt \
-in aes_key.bin \
-pubin -inkey public.pem \
-pkeyopt rsa_padding_mode:oaep \
-out encrypted_aes_key.enc

rm aes_key.bin

echo "Encryption done!"
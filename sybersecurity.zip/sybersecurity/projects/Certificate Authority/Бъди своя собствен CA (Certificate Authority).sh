echo "=== Creating Root CA ==="

openssl req -x509 \
-newkey rsa:4096 \
-keyout ca_key.pem \
-out ca_cert.pem \
-days 3650 \
-nodes \
-subj "/C=BG/O=MyCompany Root CA"

echo "Root CA created."


echo "=== Creating Web Server Certificate Request ==="

openssl req -newkey rsa:2048 \
-keyout web_key.pem \
-out web.csr \
-nodes \
-subj "/C=BG/O=MyCompany/CN=internal.mycompany.local"

echo "CSR created."


echo "=== Signing certificate with Root CA ==="

openssl x509 -req \
-in web.csr \
-CA ca_cert.pem \
-CAkey ca_key.pem \
-CAcreateserial \
-out web_cert.pem \
-days 365

echo "Certificate created successfully!"

echo "Generated files:"
echo "ca_key.pem"
echo "ca_cert.pem"
echo "web_key.pem"
echo "web.csr"
echo "web_cert.pem"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

#define DB_FILE "users.db"

void hash_password(const char *salt, const char *password, char *output) {
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    EVP_DigestInit_ex(ctx, EVP_sha256(), NULL);

    EVP_DigestUpdate(ctx, salt, strlen(salt));
    EVP_DigestUpdate(ctx, password, strlen(password));

    unsigned char hash[EVP_MAX_MD_SIZE];
    unsigned int len;

    EVP_DigestFinal_ex(ctx, hash, &len);
    EVP_MD_CTX_free(ctx);

    for (unsigned int i = 0; i < len; i++) {
        sprintf(output + i * 2, "%02x", hash[i]);
    }
    output[len * 2] = '\0';
}

void generate_salt(char *salt) {
    unsigned char buf[4];
    RAND_bytes(buf, 4);

    for (int i = 0; i < 4; i++) {
        sprintf(salt + i * 2, "%02x", buf[i]);
    }
    salt[8] = '\0';
}

void register_user() {
    char username[50], password[50];
    char salt[9];
    char hash[65];

    printf("Username: ");
    scanf("%49s", username);

    printf("Password: ");
    scanf("%49s", password);

    generate_salt(salt);
    hash_password(salt, password, hash);

    FILE *f = fopen(DB_FILE, "a");
    if (!f) {
        printf("Error opening DB\n");
        return;
    }

    fprintf(f, "%s:%s:%s\n", username, salt, hash);
    fclose(f);

    printf("User registered!\n");
}

void login_user() {
    char username[50], password[50];
    char line[200];

    printf("Username: ");
    scanf("%49s", username);

    printf("Password: ");
    scanf("%49s", password);

    FILE *f = fopen(DB_FILE, "r");
    if (!f) {
        printf("DB not found\n");
        return;
    }

    int found = 0;

    while (fgets(line, sizeof(line), f)) {
        char *file_user = strtok(line, ":");
        char *salt = strtok(NULL, ":");
        char *hash = strtok(NULL, ":\n");

        if (file_user && strcmp(file_user, username) == 0) {
            found = 1;

            char check_hash[65];
            hash_password(salt, password, check_hash);

            if (strcmp(hash, check_hash) == 0) {
                printf("Login SUCCESS\n");
            } else {
                printf("Wrong password\n");
            }
            break;
        }
    }

    if (!found) {
        printf("User not found\n");
    }

    fclose(f);
}

int main(int argc, char *argv[]) {

    if (argc != 2) {
        printf("Usage: %s [register|login]\n", argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "register") == 0) {
        register_user();
    } else if (strcmp(argv[1], "login") == 0) {
        login_user();
    } else {
        printf("Unknown mode\n");
    }

    return 0;
}
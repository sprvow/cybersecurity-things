#include <stdio.h>
#include <string.h>
#include <crypt.h>

void crack_pin(const char *target_hash) {

    char guess[5];

    printf("--- Starting PIN Brute-Force Attack ---\n");

    for (int i = 0; i <= 9999; i++) {

        sprintf(guess, "%04d", i);

        char *computed_hash = crypt(guess, target_hash);

        if (strcmp(computed_hash, target_hash) == 0) {

            printf("\n[SUCCESS] Password found: %s\n", guess);
            return;
        }
    }

    printf("\n[FAILED] Password is not a 4-digit PIN.\n");
}

int main() {

    char target_hash[] =
    "$6$xq7%3$03TJMkvoZmSoSVmWpDUuBvXNlnUelT3fLj6EvodCh1qFYjK9azoiyfxT4/gomNcpX.5Xfg08ZPU6U.xIHu8Pn.";

    crack_pin(target_hash);

    return 0;
}
#include <stdio.h>
#include <string.h>
#include <crypt.h>

void dictionary_attack(const char *target_hash, const char *dict_file) {

    FILE *file = fopen(dict_file, "r");

    if (!file) {
        printf("Error opening dictionary file!\n");
        return;
    }

    char word[256];

    printf("--- Starting Dictionary Attack ---\n");

    while (fgets(word, sizeof(word), file)) {

        word[strcspn(word, "\n")] = 0;

        char *computed_hash = crypt(word, target_hash);

        if (strcmp(computed_hash, target_hash) == 0) {

            printf("[SUCCESS] Password found: %s\n", word);

            fclose(file);
            return;
        }
    }

    printf("[FAILED] Password was not found in dictionary.\n");

    fclose(file);
}

int main() {

    char target_hash[] =
    "$6$salt$N1sFxhVxv5JH8YhU5Jf5Hf7K9LkM0xw2N7Qj8VxR1aYz6Hc3TnP9Lm4Kj2Qa";

    char dictionary[] = "rockyou_mini.txt";

    dictionary_attack(target_hash, dictionary);

    return 0;
}
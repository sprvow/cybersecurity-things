#include <stdio.h>
#include <string.h>

void xor_cipher(char *text, char key) {
    int len = strlen(text);
    for (int i = 0; i < len; i++) {
        text[i] = text[i] ^ key;
    }
}

int main() {
    char data[] = "Secret";
    char key = 'K';

    xor_cipher(data, key);
    printf("Encrypted: %s\n", data);

    xor_cipher(data, key);
    printf("Decrypted: %s\n", data);

    return 0;
}
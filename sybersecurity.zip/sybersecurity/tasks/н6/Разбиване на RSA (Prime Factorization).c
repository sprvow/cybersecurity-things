#include <stdio.h>
#include <math.h>

void factorize_rsa(long long n) {

    printf("--- Starting factorization of N = %lld ---\n", n);

    long long limit = (long long)sqrt(n);

    for (long long i = 3; i <= limit; i += 2) {

        if (n % i == 0) {

            long long p = i;
            long long q = n / i;

            printf("[SUCCESS] Factors found!\n");

            printf("p = %lld\n", p);
            printf("q = %lld\n", q);

            // Euler's Totient Function
            long long phi = (p - 1) * (q - 1);

            printf("Phi(n) = %lld\n", phi);

            return;
        }
    }

    printf("No factors found. Number may be prime.\n");
}

int main() {

    long long public_n = 3233;

    factorize_rsa(public_n);

    return 0;
}
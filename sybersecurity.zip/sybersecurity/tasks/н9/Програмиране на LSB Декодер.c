#include <stdio.h>
#include <stdlib.h>

int main() {

    FILE *img = fopen("stego_image.bmp", "rb");

    if (!img) {
        printf("Error opening file.\n");
        return 1;
    }

    fseek(img, 54, SEEK_SET);

    printf("--- Extracting Secret Message ---\n");

    unsigned char pixel;
    unsigned char secret_char = 0;

    int bit_count = 0;

    while (fread(&pixel, 1, 1, img) == 1) {

        unsigned char lsb = pixel & 1;

        secret_char =
            secret_char | (lsb << bit_count);

        bit_count++;

        if (bit_count == 8) {

            printf("%c", secret_char);

            if (secret_char == '\0')
                break;

            secret_char = 0;
            bit_count = 0;
        }
    }

    printf("\n");

    fclose(img);

    return 0;
}
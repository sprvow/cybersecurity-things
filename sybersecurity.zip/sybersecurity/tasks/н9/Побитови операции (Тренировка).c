#include <stdio.h>

void print_binary(unsigned char byte) {

    for (int i = 7; i >= 0; i--) {
        printf("%d", (byte >> i) & 1);
    }

    printf("\n");
}

int main() {

    unsigned char pixel = 155;
    unsigned char secret_bit = 0;

    printf("Original pixel: ");
    print_binary(pixel);

    pixel = pixel & 0xFE;

    pixel = pixel | secret_bit;

    printf("Modified pixel: ");
    print_binary(pixel);

    unsigned char extracted = pixel & 1;

    printf("Extracted bit: %d\n", extracted);

    return 0;
}
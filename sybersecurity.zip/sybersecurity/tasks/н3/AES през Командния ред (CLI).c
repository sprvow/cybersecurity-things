echo -n "Hello" > plain.txt

openssl enc -aes-128-ecb \
-in plain.txt \
-out cipher.bin \
-K 0112233445566778899AABBCCDDEEFF \
-nosalt

xxd cipher.bin


/* 
Входният файл е 5 байта.
Изходният файл е 16 байта.

Разликата е заради padding-а.
AES работи с блокове по 16 байта, затова OpenSSL добавя допълнителни байтове.
*/
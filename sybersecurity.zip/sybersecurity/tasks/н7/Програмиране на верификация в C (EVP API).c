#include <stdio.h>
#include <stdlib.h>
#include <openssl/evp.h>
#include <openssl/pem.h>

void handleErrors() {
    printf("Cryptographic error occurred!\n");
    exit(1);
}

int main() {

    FILE *keyfile = fopen("public.pem", "r");
    if (!keyfile) {
        printf("Missing public.pem\n");
        return 1;
    }

    EVP_PKEY *pubkey =
        PEM_read_PUBKEY(keyfile, NULL, NULL, NULL);

    fclose(keyfile);

    if (!pubkey)
        handleErrors();

    EVP_MD_CTX *mdctx = EVP_MD_CTX_new();

    if (!mdctx)
        handleErrors();

    if (1 != EVP_DigestVerifyInit(
        mdctx,
        NULL,
        EVP_sha256(),
        NULL,
        pubkey))
        handleErrors();

    FILE *docfile = fopen("contract.txt", "rb");

    if (!docfile) {
        printf("Missing contract.txt\n");
        return 1;
    }

    unsigned char buffer[1024];
    size_t bytes_read;

    while ((bytes_read =
            fread(buffer,1,sizeof(buffer),docfile)) > 0) {

        if (1 != EVP_DigestVerifyUpdate(
            mdctx,
            buffer,
            bytes_read))

            handleErrors();
    }

    fclose(docfile);

    FILE *sigfile = fopen("signature.bin", "rb");

    if (!sigfile) {
        printf("Missing signature.bin\n");
        return 1;
    }

    unsigned char signature[256];

    size_t sig_len =
        fread(signature,1,sizeof(signature),sigfile);

    fclose(sigfile);

    int result =
        EVP_DigestVerifyFinal(
            mdctx,
            signature,
            sig_len);

    if (result == 1) {

        printf("[SUCCESS] Signature is valid!\n");
        printf("Document is authentic.\n");

    }
    else if (result == 0) {

        printf("[WARNING] Invalid signature!\n");
        printf("Document was modified.\n");

    }
    else {

        printf("Verification error.\n");
    }

    EVP_MD_CTX_free(mdctx);
    EVP_PKEY_free(pubkey);

    return 0;
}
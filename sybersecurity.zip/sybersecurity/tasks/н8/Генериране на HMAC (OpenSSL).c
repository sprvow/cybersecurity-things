#include <stdio.h>
#include <string.h>
#include <openssl/hmac.h>

int main() {

    char key[] = "SuperSecretAPIKey123";

    char data[] = "amount=500&currency=BGN&to_account=BG99FINV1234";

    unsigned char result[EVP_MAX_MD_SIZE];
    unsigned int result_len;

    HMAC(
        EVP_sha256(),
        key,
        strlen(key),
        (unsigned char*)data,
        strlen(data),
        result,
        &result_len
    );

    printf("Data: %s\n", data);

    printf("HMAC-SHA256: ");

    for(int i = 0; i < result_len; i++) {
        printf("%02x", result[i]);
    }

    printf("\n");

    return 0;
}
#include <stdio.h>

long long mod_exp(long long base, long long exp, long long mod) {

    long long result = 1;

    base = base % mod;

    while (exp > 0) {

        if (exp % 2 == 1)
            result = (result * base) % mod;

        exp = exp >> 1;

        base = (base * base) % mod;
    }

    return result;
}

int main() {

    printf("--- Diffie-Hellman Key Exchange ---\n");

    long long p = 23;
    long long g = 5;

    printf("Public values: p = %lld, g = %lld\n\n", p, g);

    long long a = 4;
    long long A = mod_exp(g, a, p);

    printf("Alice sends: A = %lld\n", A);

    long long b = 3;
    long long B = mod_exp(g, b, p);

    printf("Bob sends: B = %lld\n\n", B);

    long long secret_Alice = mod_exp(B, a, p);

    long long secret_Bob = mod_exp(A, b, p);

    printf("Alice Secret Key: %lld\n", secret_Alice);
    printf("Bob Secret Key: %lld\n", secret_Bob);

    if (secret_Alice == secret_Bob) {
        printf("[SUCCESS] Shared keys match!\n");
    }
    else {
        printf("[ERROR] Shared keys do not match!\n");
    }

    return 0;
}
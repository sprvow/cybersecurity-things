#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {

    FILE *input = fopen("image.bmp", "rb");
    FILE *output = fopen("output.bmp", "wb");

    if (!input || !output) {
        printf("Error opening file.\n");
        return 1;
    }

    char secret[] = "Hello";
    int message_len = strlen(secret) + 1;

    unsigned char byte;

    for (int i = 0; i < 54; i++) {
        fread(&byte, 1, 1, input);
        fwrite(&byte, 1, 1, output);
    }

    for (int i = 0; i < message_len; i++) {

        unsigned char current_char = secret[i];

        for (int bit = 0; bit < 8; bit++) {

            fread(&byte, 1, 1, input);

            unsigned char secret_bit =
                (current_char >> bit) & 1;

            byte = byte & 0xFE;

            byte = byte | secret_bit;

            fwrite(&byte, 1, 1, output);
        }
    }

    while (fread(&byte, 1, 1, input) == 1) {
        fwrite(&byte, 1, 1, output);
    }

    fclose(input);
    fclose(output);

    printf("Message hidden successfully!\n");

    return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void rc4_crypt(unsigned char *key, int keylen, unsigned char *data, int datalen, unsigned char *output) {
    unsigned char S[256];
    int i, j = 0;
    unsigned char temp;

    for (i = 0; i < 256; i++) S[i] = i;

    for (i = 0; i < 256; i++) {
        j = (j + S[i] + key[i % keylen]) % 256;

        temp = S[i];
        S[i] = S[j];
        S[j] = temp;
    }

    i = 0;
    j = 0;

    for (int k = 0; k < datalen; k++) {
        i = (i + 1) % 256;
        j = (j + S[i]) % 256;

        temp = S[i];
        S[i] = S[j];
        S[j] = temp;

        unsigned char keystream = S[(S[i] + S[j]) % 256];

        output[k] = data[k] ^ keystream;
    }
}

int main(int argc, char *argv[]) {

    if (argc != 4) {
        printf("Usage: ./rc4_file input output key\n");
        return 1;
    }

    FILE *in = fopen(argv[1], "rb");
    FILE *out = fopen(argv[2], "wb");

    if (!in || !out) {
        printf("File error\n");
        return 1;
    }

    fseek(in, 0, SEEK_END);
    int size = ftell(in);
    rewind(in);

    unsigned char *buffer = malloc(size);
    unsigned char *result = malloc(size);

    fread(buffer, 1, size, in);

    rc4_crypt((unsigned char*)argv[3], strlen(argv[3]), buffer, size, result);

    fwrite(result, 1, size, out);

    free(buffer);
    free(result);

    fclose(in);
    fclose(out);

    printf("Done.\n");

    return 0;
}
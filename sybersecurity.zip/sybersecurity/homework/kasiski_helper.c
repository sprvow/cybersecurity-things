#include <stdio.h>
#include <string.h>

void find_trigrams(char *text) {
    int len = strlen(text);

    for (int i = 0; i < len - 2; i++) {
        for (int j = i + 1; j < len - 2; j++) {

            if (strncmp(&text[i], &text[j], 3) == 0) {

                printf("Found \"%.3s\": Pos %d & Pos %d -> Distance: %d\n",
                       &text[i], i, j, j - i);
            }
        }
    }
}

int main() {
    char text[] = "ABCXYZABCDEFABC";

    find_trigrams(text);

    return 0;
}
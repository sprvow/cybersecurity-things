#include <stdio.h>
#include <ctype.h>
#include <string.h>

char decrypt_char(char c, int k) {
    if (isupper(c))
        return ((c - 'A' - k + 26) % 26) + 'A';
    return c;
}

void decrypt_with_key(char *text, int key) {
    char temp[100];

    for (int i = 0; i < strlen(text); i++) {
        temp[i] = decrypt_char(text[i], key);
    }
    temp[strlen(text)] = '\0';

    printf("Key %2d: %s\n", key, temp);
}

int main() {
    char text[] = "WKLV LV D VHFUHW PHVVDJH";

    for (int k = 1; k <= 25; k++) {
        decrypt_with_key(text, k);
    }

    return 0;
}
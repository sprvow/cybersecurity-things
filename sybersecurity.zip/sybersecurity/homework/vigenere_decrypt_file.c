#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void vigenere_decrypt(const char *input, const char *key, char *output) {
    int key_len = strlen(key);
    int key_index = 0;

    for (int i = 0; input[i] != '\0'; i++) {
        char c = toupper(input[i]);

        if (isalpha(c)) {
            char k = toupper(key[key_index % key_len]);
            int shift = k - 'A';

            output[i] = ((c - 'A' - shift + 26) % 26) + 'A';
            key_index++;
        } else {
            output[i] = input[i];
        }
    }

    output[strlen(input)] = '\0';
}

int main() {
    FILE *fin = fopen("encrypted.txt", "r");
    FILE *fkey = fopen("key.txt", "r");
    FILE *fout = fopen("decrypted.txt", "w");

    if (!fin || !fkey || !fout) {
        printf("File error\n");
        return EXIT_FAILURE;
    }

    char text[1000];
    char key[100];

    fgets(text, sizeof(text), fin);
    fgets(key, sizeof(key), fkey);

    text[strcspn(text, "\n")] = 0;
    key[strcspn(key, "\n")] = 0;

    char result[1000];

    vigenere_decrypt(text, key, result);

    fprintf(fout, "%s", result);

    fclose(fin);
    fclose(fkey);
    fclose(fout);

    printf("Decrypted successfully!\n");

    return EXIT_SUCCESS;
}
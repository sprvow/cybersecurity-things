#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

char encrypt_char(char c, int k) {
    if (isupper(c))
        return ((c - 'A' + k) % 26) + 'A';
    else if (islower(c))
        return ((c - 'a' + k) % 26) + 'a';
    return c;
}

char decrypt_char(char c, int k) {
    if (isupper(c))
        return ((c - 'A' - k + 26) % 26) + 'A';
    else if (islower(c))
        return ((c - 'a' - k + 26) % 26) + 'a';
    return c;
}

int main(int argc, char *argv[]) {
    if (argc != 5) {
        printf("Usage:\n");
        printf("./caesar_tool -e input.txt key.txt output.txt\n");
        printf("./caesar_tool -d input.txt key.txt output.txt\n");
        return EXIT_FAILURE;
    }

    FILE *in = fopen(argv[2], "r");
    FILE *keyfile = fopen(argv[3], "r");
    FILE *out = fopen(argv[4], "w");

    if (!in || !keyfile || !out) {
        printf("Error opening files\n");
        return EXIT_FAILURE;
    }

    int key;
    fscanf(keyfile, "%d", &key);

    int ch;
    while ((ch = fgetc(in)) != EOF) {
        char result;
        if (argv[1][1] == 'e')
            result = encrypt_char(ch, key);
        else
            result = decrypt_char(ch, key);

        fputc(result, out);
    }

    fclose(in);
    fclose(keyfile);
    fclose(out);

    return EXIT_SUCCESS;
}
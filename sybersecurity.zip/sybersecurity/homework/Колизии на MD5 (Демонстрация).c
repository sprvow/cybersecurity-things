#include <stdio.h>
#include <string.h>
#include <openssl/evp.h>

void hash_file(const char *filename, const EVP_MD *type,
               unsigned char *out, unsigned int *out_len) {

    FILE *f = fopen(filename, "rb");
    if (!f) {
        printf("Cannot open file\n");
        return;
    }

    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    EVP_DigestInit_ex(ctx, type, NULL);

    unsigned char buffer[1024];
    int len;

    while ((len = fread(buffer, 1, sizeof(buffer), f)) > 0) {
        EVP_DigestUpdate(ctx, buffer, len);
    }

    EVP_DigestFinal_ex(ctx, out, out_len);

    EVP_MD_CTX_free(ctx);
    fclose(f);
}

void print_hash(unsigned char *hash, unsigned int len) {
    for (unsigned int i = 0; i < len; i++)
        printf("%02x", hash[i]);
    printf("\n");
}

int main() {

    unsigned char md5_1[EVP_MAX_MD_SIZE], md5_2[EVP_MAX_MD_SIZE];
    unsigned char sha1[EVP_MAX_MD_SIZE], sha2[EVP_MAX_MD_SIZE];
    unsigned int len;

    hash_file("file1.pdf", EVP_md5(), md5_1, &len);
    hash_file("file2.pdf", EVP_md5(), md5_2, &len);

    printf("MD5 file1: "); print_hash(md5_1, len);
    printf("MD5 file2: "); print_hash(md5_2, len);

    if (memcmp(md5_1, md5_2, len) == 0)
        printf("[!] MD5 collision detected\n");

    hash_file("file1.pdf", EVP_sha256(), sha1, &len);
    hash_file("file2.pdf", EVP_sha256(), sha2, &len);

    printf("SHA256 file1: "); print_hash(sha1, len);
    printf("SHA256 file2: "); print_hash(sha2, len);

    if (memcmp(sha1, sha2, len) != 0)
        printf("[+] SHA256 different\n");

    return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>

void handle_errors() {
    printf("Error occurred\n");
    exit(1);
}

void encrypt(unsigned char *in, int in_len,
             unsigned char *key, unsigned char *iv,
             unsigned char *out, int *out_len) {

    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    int len;

    EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv);

    EVP_EncryptUpdate(ctx, out, &len, in, in_len);
    *out_len = len;

    EVP_EncryptFinal_ex(ctx, out + len, &len);
    *out_len += len;

    EVP_CIPHER_CTX_free(ctx);
}

int decrypt(unsigned char *in, int in_len,
            unsigned char *key, unsigned char *iv,
            unsigned char *out, int *out_len) {

    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    int len;

    EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv);

    EVP_DecryptUpdate(ctx, out, &len, in, in_len);
    *out_len = len;

    if (EVP_DecryptFinal_ex(ctx, out + len, &len) <= 0) {
        EVP_CIPHER_CTX_free(ctx);
        return 0;
    }

    *out_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return 1;
}

int main(int argc, char *argv[]) {

    if (argc != 5) {
        printf("Usage: %s [enc|dec] input output key\n", argv[0]);
        return 1;
    }

    char *mode = argv[1];

    FILE *fin = fopen(argv[2], "rb");
    FILE *fout = fopen(argv[3], "wb");

    if (!fin || !fout) {
        printf("File error\n");
        return 1;
    }

    fseek(fin, 0, SEEK_END);
    int size = ftell(fin);
    rewind(fin);

    unsigned char *buffer = malloc(size);
    fread(buffer, 1, size, fin);

    unsigned char *out = malloc(size + 32);

    int out_len;

    unsigned char key[16] = {0};
    strncpy((char*)key, argv[4], 16);

    unsigned char iv[16] = "1234567890123456";

    if (strcmp(mode, "enc") == 0) {

        encrypt(buffer, size, key, iv, out, &out_len);
        fwrite(out, 1, out_len, fout);
        printf("Encrypted\n");

    } else if (strcmp(mode, "dec") == 0) {

        if (!decrypt(buffer, size, key, iv, out, &out_len)) {
            printf("Decryption failed (bad key or padding)\n");
        } else {
            fwrite(out, 1, out_len, fout);
            printf("Decrypted\n");
        }

    } else {
        printf("Invalid mode (use enc or dec)\n");
    }

    free(buffer);
    free(out);

    fclose(fin);
    fclose(fout);

    return 0;
}
#include <stdio.h>
#include <string.h>
#include <openssl/evp.h>

void encrypt(unsigned char *plaintext, int plaintext_len,
             unsigned char *key, unsigned char *iv,
             unsigned char *ciphertext, int *ciphertext_len) {

    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    int len;

    EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv);

    EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len);
    *ciphertext_len = len;

    EVP_EncryptFinal_ex(ctx, ciphertext + len, &len);
    *ciphertext_len += len;

    EVP_CIPHER_CTX_free(ctx);
}

int decrypt(unsigned char *ciphertext, int ciphertext_len,
            unsigned char *key, unsigned char *iv,
            unsigned char *plaintext, int *plaintext_len) {

    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    int len;

    EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv);

    EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len);
    *plaintext_len = len;

    if (EVP_DecryptFinal_ex(ctx, plaintext + len, &len) <= 0) {
        EVP_CIPHER_CTX_free(ctx);
        return 0;
    }

    *plaintext_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return 1;
}

int main() {

    unsigned char key[16] = "1234567890123456";
    unsigned char iv[16]  = "abcdefghijklmnop";

    unsigned char text[] = "Hello Cyber Security!";
    unsigned char ciphertext[128];
    unsigned char decrypted[128];

    int cipher_len, decrypted_len;

    printf("Original: %s\n", text);

    // encrypt
    encrypt(text, strlen((char*)text), key, iv, ciphertext, &cipher_len);

    printf("Encrypted (hex): ");
    for(int i = 0; i < cipher_len; i++) {
        printf("%02X ", ciphertext[i]);
    }
    printf("\n");

    // decrypt
    if(decrypt(ciphertext, cipher_len, key, iv, decrypted, &decrypted_len)) {
        decrypted[decrypted_len] = '\0';
        printf("Decrypted: %s\n", decrypted);
    } else {
        printf("Decryption failed (bad padding or key)\n");
    }

    return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

unsigned char rc4_second_byte(unsigned char *key, int keylen) {
    unsigned char S[256];
    int i, j = 0;
    unsigned char temp;

    for (i = 0; i < 256; i++) S[i] = i;

    for (i = 0; i < 256; i++) {
        j = (j + S[i] + key[i % keylen]) % 256;
        temp = S[i]; S[i] = S[j]; S[j] = temp;
    }

    i = 0; j = 0;

    i = (i + 1) % 256;
    j = (j + S[i]) % 256;
    temp = S[i]; S[i] = S[j]; S[j] = temp;
    unsigned char dummy = S[(S[i] + S[j]) % 256];

    i = (i + 1) % 256;
    j = (j + S[i]) % 256;
    temp = S[i]; S[i] = S[j]; S[j] = temp;

    return S[(S[i] + S[j]) % 256];
}

int main() {
    int count = 0;
    unsigned char key[5];

    srand(time(NULL));

    for (int i = 0; i < 100000; i++) {
        for (int j = 0; j < 5; j++) {
            key[j] = rand() % 256;
        }

        if (rc4_second_byte(key, 5) == 0x00) {
            count++;
        }
    }

    printf("Second byte = 0x00 count: %d\n", count);

    return 0;
}